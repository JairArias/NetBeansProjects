/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicios;

import Entidades.Juego;
import Entidades.Jugador;
import Entidades.RevolverDeAgua;
import java.util.ArrayList;

import java.util.Scanner;

/**
 *
 * @author Ryzen
 */
public class ServiciosJuego {

    //ArrayList<Jugador> jugadores = new ArrayList();
    Scanner leer = new Scanner(System.in);
    Jugador ju = new Jugador();
    ServiciosJugador sj = new ServiciosJugador();
    RevolverDeAgua rev ;
    Juego jue = new Juego();
    ServiciosRevolverDeAgua sra = new ServiciosRevolverDeAgua();

    public void LlenarJuego() {

        ju = sj.cantidadJugadores();
        jue.setJugadores(ju.getJugadores());

        for (Jugador jugadore : jue.getJugadores()) {
            System.out.println(jugadore);
        }
       
        jue.setRevolverdeagua(rev);
        rev = sra.LlenarRevolver();
    }

    public void ronda() {
      
       // rev.getPosicionagua();
        //rev = sra.LlenarRevolver();
        sra.LlenarRevolver();
        boolean empieza = false;
        while (!empieza) {

            for (Jugador jugadore : jue.getJugadores()) {
                sj.disparo();
               
                empieza = jugadore.getMojado();
                //empieza = ju.getMojado();
                break;
            }
        }
        //System.out.println("Desea iniciar el juego S/N: ");
        //String respuesta = leer.nextLine();
        //if (respuesta.equalsIgnoreCase("S")) {

        // System.out.println();
        //  }
    }

}
