/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

import java.util.ArrayList;

/**
 *
 * @author Ryzen
 */
public class Jugador {

    private Integer id;
    private String jugador;
    private boolean mojado;
    private ArrayList<Jugador> jugadores;

    //constructor
    public Jugador() {
    }

    public Jugador(Integer id, String jugador, boolean mojado, ArrayList<Jugador> jugadores) {
        this.id = id;
        this.jugador = jugador;
        this.mojado = mojado;
        this.jugadores = jugadores;
    }

    //get & setter
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id + 1;
    }

    public String getJugador() {
        return jugador;
    }

    public void setJugador(String jugador) {
        this.jugador = jugador + id;
    }

    public boolean getMojado() {
        return mojado;
    }

    public void setMojado(boolean mojado) {
        this.mojado = mojado;
    }

    public ArrayList<Jugador> getJugadores() {
        return jugadores;
    }

    public void setJugadores(ArrayList<Jugador> jugadores) {
        this.jugadores = jugadores;
    }
    
    @Override
    public String toString() {
        return "Jugador{" + "id=" + id + ", jugador=" + jugador + ", mojado="
                + mojado + '}';
    }
    
  
    

}
