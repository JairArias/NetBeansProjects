/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicios;

import Entidades.RevolverDeAgua;
import Entidades.Jugador;
import Servicios.ServiciosRevolverDeAgua;
import java.util.Scanner;
import java.util.ArrayList;

/**
 *
 * @author Ryzen
 */
public class ServiciosJugador {

    Scanner leer = new Scanner(System.in);
    ArrayList<Jugador> jugadores = new ArrayList();
    Jugador ju;
    ServiciosRevolverDeAgua ra = new ServiciosRevolverDeAgua();

    /**
     * Se asigna la cantidad de jugadores que participaran
     */
    public Jugador cantidadJugadores() {

        System.out.println("La cantidad maxima de jugadores es 6, ¡Recuerda!");
        System.out.println("Ingrese el numero de jugadores");
        int num = leer.nextInt();
        if (num < 0 || num > 6) {
            num = 6;
        }
        for (int i = 0; i < num; i++) {
            ju = new Jugador();
            ju.setId(i);
            ju.setJugador("Jugador ");
            ju.setMojado(false);
            jugadores.add(ju);
            System.out.println(ju.getJugador());
            // System.out.println(ju.getJugadores());
            
        }
        for (Jugador jugadore : jugadores) {
            jugadore.setJugadores(jugadores);
            //System.out.println(jugadore.getJugadores());
        }
        return ju;
    }

    /**
     * llama el metodo para cargar la pistola llama el metodo de disparar, si se
     * moja muestra verdadero sino llama el metodo siguiente chorro que cambia
     * de posicion el tambor
     */
    public void disparo() {
       // ra.LlenarRevolver();
        if (ra.Mojar()) {
            ju.setMojado(true);
            System.out.println("Caramba, te has mojado!" + ra.Mojar());

        } else {
            System.out.println(ra.SiguienteChorro());
            
        }

    }

    /**
     * imprime la lista de jugadores
     */
    public void jugadoresRuleta() {
        for (Jugador jugadore : jugadores) {
            System.out.println(jugadore);
        }
    }
}
