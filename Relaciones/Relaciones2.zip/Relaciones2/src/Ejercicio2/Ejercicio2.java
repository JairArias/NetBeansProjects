/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio2;

import Servicios.ServiciosRevolverDeAgua;
import Servicios.ServiciosJugador;
import Servicios.ServiciosJuego;

/**
 *
 * @author Ryzen
 */
public class Ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        ServiciosRevolverDeAgua sra = new ServiciosRevolverDeAgua();
        ServiciosJugador sj = new ServiciosJugador();
        ServiciosJuego sju = new ServiciosJuego();
        System.out.println("Bienvenido al Juego del Revolver de Agua!!!");
        //sra.LlenarRevolver();
        //sra.Mojar();
        //sra.SiguienteChorro();
        //sj.cantidadJugadores();
        // sj.jugadoresRuleta();
        //sj.disparo();
        // sj.jugadoresRuleta();
        sju.LlenarJuego();
        sju.ronda();
    }
}
