/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicios;

import Entidades.RevolverDeAgua;
import java.util.Random;

/**
 *
 * @author Ryzen
 */
public class ServiciosRevolverDeAgua {

    Random variable = new Random();
    RevolverDeAgua ra = new RevolverDeAgua();

    /**
     * Llena la posicion actual del tambor y la poscicion del chorro de agua
     *
     * @return la posicion del tambor y agua
     */
    public RevolverDeAgua LlenarRevolver() {
        ra.setPosicionactual((int) variable.nextInt(6 - 1 + 1) + 1);
        ra.setPosicionagua((int) variable.nextInt(6 - 1 + 1) + 1);

        System.out.println(ra.getPosicionactual());
        System.out.println(ra.getPosicionagua());

        return ra;
    }

    /**
     * si la posicion del agua y del tambor coinciden moja al jugador
     *
     * @return verdadero si se moja o falso si no
     */
    public boolean Mojar() {
        boolean valida = false;
        //System.out.println("PA"+ ra.getPosicionactual() + "PAGUA"+ra.getPosicionagua());
        if (ra.getPosicionactual().equals(ra.getPosicionagua())) {
            valida = true;
            System.out.println((ra.getPosicionactual().intValue() == ra.getPosicionagua().intValue()));
        }
        return valida;

    }

    /**
     * el tambor cambia a la siguiente posicion para ser disparado de nuevo
     */
    public int SiguienteChorro() {
        if (ra.getPosicionactual().equals(6)) {
            ra.setPosicionactual(1);
        } else {
            ra.setPosicionactual(ra.getPosicionactual() + 1);
        }
        return ra.getPosicionactual();
    }

    /**
     * imprime las posiciones
     */
    @Override
    public String toString() {

        String m = "Posicion actual revolver: " + ra.getPosicionactual() + "; Posicion del agua: " + ra.getPosicionagua();
        System.out.println(m);
        return ra.toString();

    }

}
